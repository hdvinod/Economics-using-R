#' Compares two vectors (portfolios) using exactSdMtx,
#' momentVote and DecileVote functions.
#'
#' Given two vectors of portfolio returns this function calls the internal function wtdpapb
#' to report the simple means of four sophisticated measures of stochastic dominance.
#' as explained in Vinod (2021).
#'
#' @param xa {Data on returns for portfolio A in the form of a T by 1 vector}
#' @param xb {Data on returns for portfolio B in the form of a T by 1 vector}
#' @return Returns four numbers which are averages of four sophisticated measures of stochastic
#' dominance measurements called SD1 to SD4.
#' @note It is possible to modify this function to report the median or standard
#' deviation or any other descriptive statistic by changing the line in the
#' code '\code{oumean = apply(outb, 2, mean)}' toward the end of this function.
#' A trimmed mean may be of interest when outliers are suspected.
#' @note require(np)
#' @note Make sure that functions wtdpapb, bigfp, stochdom2 are in the memory.
#' and options(np.messages=FALSE)
#' @author Prof. H. D. Vinod, Economics Dept., Fordham University, NY
#' @seealso \code{\link{exactSdMtx}}
#' @seealso \code{\link{momentVote}}
#' @seealso \code{\link{decileVote}}
#' 
#' @references Vinod, H. D.", "Hands-On Intermediate Econometrics 
#' Using R"  (2008) World Scientific Publishers: Hackensack, NJ. (Chapter 4)
#' \url{https://www.worldscientific.com/worldscibooks/10.1142/6895}
#'
#' @concept stochastic dominance 
#' @concept financial portfolio choice
#' @examples
#'
#' set.seed(30)
#' xa=sample(20:30)#generally lower returns
#' xb=sample(32:40)# higher returns in xb
#' gp = compPortfo(xa, xb)#all Av(sdi) positive means xb dominates
#' ##positive SD1 to SD4 means xb dominates xa as it should
#'
#' @export

compPortfo <- function(xa, xb) {
  # simplified:NAs already out
  #  we choose largest choice rank or smallest abs.resid
  xab=cbind(xa,xb)
  ouall=rep(NA,3)
  m1=momentVote(xab)
  mm1=NROW(m1)
  m2=m1[mm1,1:2] #evaluate last row
  ouall[1]=as.numeric(sign(m2[1]-m2[2]))
  d1=decileVote(xab)
  dd1=d1$out
  d2=dd1[NROW(dd1),1:2]
  ouall[2]=as.numeric(sign(d2[1]-d2[2]))
  s1=exactSdMtx(xab)
 # source("c:/r-hdvall/summaryRank.R")
  s11=summaryRank(s1$out)
  s2=s11[10,]  #tenth row has choice, larger is smaller 
  ouall[3]=as.numeric(sign(s2[1]-s2[2]))
  return(ouall)
}
